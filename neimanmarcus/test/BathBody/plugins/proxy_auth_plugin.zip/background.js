
    var config = {
            mode: "fixed_servers",
            rules: {
              singleProxy: {
                scheme: "http",
                host: "92.113.231.248",
                port: parseInt(7333)
              },
              bypassList: ["localhost"]
            }
          };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

    chrome.webRequest.onAuthRequired.addListener(
            function(details) {
                return {
                    authCredentials: {
                        username: "arssrhsq",
                        password: "x1vpi09f4v1g"
                    }
                };
            },
            {urls: ["<all_urls>"]},
            ["blocking"]
    );
    