# queri.py
def cari():
    return 'makeup/all' # Pastikan menggunakan return 

    # ganti dengan pencarian baru ini

#    1 # makeup/all
#    2 # skin-care/all
#    3 # hair/all
#    4 # wellness-shop/all
#    5 # tools-brushes/all
#    6 # fragrance/all
#    7 # body-care/all
#    8 # men/all
#    9 # travel-size-mini/all


