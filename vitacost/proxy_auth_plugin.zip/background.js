
    var config = {
            mode: "fixed_servers",
            rules: {
            singleProxy: {
                scheme: "http",
                host: "dc.decodo.com",
                port: parseInt(10004)
            },
            bypassList: ["localhost"]
            }
        };

    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    chrome.webRequest.onAuthRequired.addListener(
        function(details) {
            return {
                authCredentials: {
                    username: "user-spdv8itjmq-country-us",
                    password: "0uHrpir4~kH9Ipb6Wg"
                }
            };
        },
        {urls: ["<all_urls>"]},
        ["blocking"]
    );
    